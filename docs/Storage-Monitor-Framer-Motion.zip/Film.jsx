import React from "react";
import {
  AbsoluteFill,
  Composition,
  Img,
  Sequence,
  registerRoot,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Audio } from "@remotion/media";
import { motion, cubicBezier } from "framer-motion";
const FPS = 24,
  DURATION = 64;
const ink = "#152234",
  navy = "#101e36",
  blue = "#2659db",
  soft = "#edf2ff",
  green = "#147953",
  red = "#bf3f4f";
const fonts = 'Geist, "Segoe UI", sans-serif';
const curve = cubicBezier(0.22, 0.78, 0.18, 1);
const cap = (t, a, b) => Math.max(0, Math.min(1, (t - a) / (b - a)));
const ease = (t, a, b) => curve(cap(t, a, b));
const abs = (left, top, extra = {}) => ({ position: "absolute", left, top, ...extra });
function Time() {
  const frame = useCurrentFrame(),
    { fps } = useVideoConfig();
  return frame / fps;
}
function Text({
  x,
  y,
  w,
  size,
  children,
  color = ink,
  weight = 580,
  leading = 1.06,
  spacing = -0.053,
  style = {},
}) {
  return (
    <div
      style={abs(x, y, {
        width: w,
        fontSize: size,
        color,
        fontWeight: weight,
        lineHeight: leading,
        letterSpacing: spacing + "em",
        ...style,
      })}
    >
      {children}
    </div>
  );
}
function Rise({ t, delay = 0, children, dist = 35 }) {
  const p = ease(t, delay, delay + 0.72);
  return (
    <motion.div style={{ position: "absolute", inset: 0, y: (1 - p) * dist, opacity: p }}>
      {children}
    </motion.div>
  );
}
function Archive({ size = 31, color = "currentColor" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      stroke={color}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 6h22v6H5z M7.5 12v13a1.5 1.5 0 001.5 1.5h14a1.5 1.5 0 001.5-1.5V12 M12.5 16.5h7" />
    </svg>
  );
}
function Brand({ dark = false, tab }) {
  const color = dark ? "#f4f7ff" : ink;
  return (
    <>
      <div
        style={abs(72, 40, {
          color,
          display: "flex",
          alignItems: "center",
          gap: 13,
          fontSize: 25,
          fontWeight: 640,
          letterSpacing: "-.045em",
        })}
      >
        <span
          style={{
            display: "grid",
            placeItems: "center",
            width: 42,
            height: 42,
            borderRadius: 12,
            background: dark ? "#eaf1ff" : blue,
            color: dark ? blue : "white",
          }}
        >
          <Archive />
        </span>
        Storage Monitor
      </div>
      <div
        style={abs(945, 50, {
          width: 583,
          textAlign: "right",
          fontSize: 17,
          fontWeight: 550,
          letterSpacing: ".075em",
          color: dark ? "#d7e6ff" : "#52637c",
        })}
      >
        {tab.toUpperCase()}
      </div>
    </>
  );
}
function Footer({ t, offset, children, dark = false }) {
  return (
    <>
      <div
        style={abs(72, 765, {
          width: 1456,
          height: 1,
          background: dark ? "#ffffff3b" : "#b8c4d7",
        })}
      />
      <div
        style={abs(72, 789, {
          fontSize: 28,
          lineHeight: 1.24,
          color: dark ? "#f6f8ff" : ink,
          letterSpacing: "-.027em",
          maxWidth: 1300,
        })}
      >
        {children}
      </div>
      <div
        style={abs(72, 861, {
          width: 1456,
          height: 3,
          background: dark ? "#ffffff27" : "#d7dfeb",
        })}
      >
        <div
          style={{
            width: ((offset + t) / DURATION) * 100 + "%",
            height: 3,
            background: dark ? "#9accff" : blue,
          }}
        />
      </div>
      <div
        style={abs(1240, 840, {
          width: 288,
          textAlign: "right",
          fontSize: 13,
          letterSpacing: ".09em",
          color: dark ? "#d5e4f8" : "#566784",
        })}
      >
        ILLUSTRATIVE READINGS
      </div>
    </>
  );
}
function Surface({ color = "#f4f6fa", children }) {
  return (
    <AbsoluteFill style={{ background: color, overflow: "hidden" }}>
      {children}
    </AbsoluteFill>
  );
}
function Shot({ name, x = 0, y = 0, w, style = {} }) {
  return (
    <Img
      src={staticFile(name + ".png")}
      style={abs(x, y, { width: w, height: "auto", display: "block", ...style })}
    />
  );
}
const shadow = "0 18px 44px rgba(20,45,89,.13), 0 1px 3px rgba(20,45,89,.11)";
function Dots({ dark = false }) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        backgroundImage:
          "radial-gradient(" +
          (dark ? "#d0e7ff33" : "#2a64bd28") +
          " .9px, transparent 1px)",
        backgroundSize: "26px 26px",
        maskImage: "linear-gradient(110deg,transparent 22%,black 95%)",
      }}
    />
  );
}
function Label({ x, y, children, color = blue }) {
  return (
    <Text x={x} y={y} size={19} weight={670} color={color} spacing={0.055}>
      {children}
    </Text>
  );
}
function Cursor({ x, y, p }) {
  return (
    <div
      style={abs(x, y, {
        opacity: p,
        width: 42,
        height: 48,
        filter: "drop-shadow(0 2px 2px #0004)",
      })}
    >
      <svg viewBox="0 0 36 43" width="36" height="43">
        <path
          d="M4 2L30 23L17 24L24 37L17 40L11 26L4 34Z"
          fill="#192439"
          stroke="white"
          strokeWidth="2.5"
        />
      </svg>
    </div>
  );
}
function Open() {
  const t = Time(),
    p = ease(t, 0.06, 1.35),
    cam = ease(t, 0.5, 5.95);
  return (
    <Surface color="#eaf0fc">
      <Dots />
      <Brand tab="Records Room · Application tour" />
      <Rise t={t} delay={0.05}>
        <Label x={76} y={203}>
          DOCUMENT STORAGE MONITOR
        </Label>
        <Text x={69} y={263} w={725} size={116} weight={650} leading={0.98}>
          Is the records
          <br />
          room <span style={{ color: blue }}>dry?</span>
        </Text>
      </Rise>
      <motion.div
        style={abs(802, 163, {
          width: 1040,
          height: 572,
          overflow: "hidden",
          border: "7px solid #fff",
          borderRadius: 24,
          boxShadow: shadow,
          transformOrigin: "left center",
          rotate: -2.5 + 0.8 * cam,
          x: 90 * (1 - p) - 18 * cam,
          y: 18 * (1 - p),
          opacity: p,
          background: "white",
        })}
      >
        <Shot name="overview" w={1010} />
      </motion.div>
      <Footer t={t} offset={0}>
        Start in Overview. Four cards show the last reported conditions in the room.
      </Footer>
    </Surface>
  );
}
function Water() {
  const t = Time(),
    wet = t >= 4.5,
    change = ease(t, 4.5, 5.05),
    enter = ease(t, 0, 0.75);
  return (
    <Surface color="#173f98">
      <Dots dark />
      <Brand dark tab="Overview · Water sensor" />
      <Rise t={t}>
        <Text x={72} y={135} size={77} color="white" weight={620}>
          {wet ? "Water reached the probe." : "Watch the water sensor."}
        </Text>
      </Rise>
      <div
        style={abs(71, 260, {
          width: 1458,
          height: 400,
          borderRadius: 38,
          background: "linear-gradient(110deg,#3669cf,#254fa5)",
          border: "1px solid #729efa80",
        })}
      />
      {[
        ["dry", "wet"],
        ["normalCount", "openCount"],
      ].map(([a, b], i) => (
        <motion.div
          key={a}
          style={abs(122 + i * 700, 307, {
            width: 653,
            height: 310,
            overflow: "hidden",
            borderRadius: 22,
            boxShadow: "0 14px 38px #0d225535",
            background: "white",
            y: (1 - enter) * 42 - (wet ? Math.sin(change * Math.PI) * 9 : 0),
            opacity: enter,
          })}
        >
          <Shot name={a} w={653} />
          {wet && <Shot name={b} w={653} style={{ opacity: change }} />}
        </motion.div>
      ))}
      {wet && (
        <motion.div
          style={abs(122, 307, {
            width: 653,
            height: 310,
            boxSizing: "border-box",
            border: "5px solid #ffa7a9",
            borderRadius: 22,
            opacity: (1 - change) * 0.85,
          })}
        />
      )}
      <Footer dark t={t} offset={6}>
        {wet
          ? "The first saved wet reading opens a critical water incident. The dashboard updates over WebSocket."
          : "Dry means the last accepted reading reported no water at the probe."}
      </Footer>
    </Surface>
  );
}
function History() {
  const t = Time(),
    closed = t >= 5.5,
    step = ease(t, 5.5, 6.2),
    p = ease(t, 0, 0.65);
  return (
    <Surface color="#f2f5fa">
      <Brand tab="Alerts · Recorded incidents" />
      <Rise t={t}>
        <Text x={72} y={135} size={77} weight={620}>
          When did it clear?
        </Text>
      </Rise>
      <div
        style={abs(72, 263, {
          width: 1456,
          height: 320,
          background: "white",
          borderRadius: 18,
          boxShadow: shadow,
          overflow: "hidden",
          transform: "translateY(" + (1 - p) * 26 + "px)",
        })}
      >
        <Shot name="incidentOpen" w={1456} />
        {closed && <Shot name="incidentClosed" w={1456} style={{ opacity: step }} />}
      </div>
      <div
        style={abs(75, 625, {
          display: "flex",
          gap: 22,
          alignItems: "center",
          color: closed ? green : red,
          fontSize: 31,
          fontWeight: 610,
          letterSpacing: "-.04em",
        })}
      >
        <span
          style={{
            width: 14,
            height: 14,
            borderRadius: "50%",
            background: "currentColor",
          }}
        />
        {closed ? "Cleared" : "Open"}
        <span style={{ fontWeight: 420, color: "#506175" }}>
          {closed
            ? "The end time is saved in the same row."
            : "The start time stays with the incident."}
        </span>
      </div>
      <Footer t={t} offset={16}>
        {closed
          ? "The server clears the incident after dry readings span 10 seconds."
          : "Open Alerts to see the type, severity and start time. The timestamps use Philippine time."}
      </Footer>
    </Surface>
  );
}
function Readings() {
  const t = Time(),
    p = ease(t, 0, 0.8),
    aim = ease(t, 3.5, 5.15),
    click = cap(t, 5.2, 5.85);
  return (
    <Surface color="#e9eff8">
      <Brand tab="Readings · Saved measurements" />
      <Rise t={t}>
        <Text x={72} y={124} size={73} weight={620}>
          Trace the alert back to a reading.
        </Text>
      </Rise>
      <motion.div
        style={abs(73, 245, {
          width: 1454,
          height: 475,
          overflow: "hidden",
          borderRadius: 18,
          boxShadow: shadow,
          y: (1 - p) * 35,
          opacity: p,
          background: "white",
        })}
      >
        <Shot name="readings" w={1454} />
      </motion.div>
      <Cursor x={868 + aim * 500} y={557 - aim * 255} p={ease(t, 2.8, 3.4)} />
      {click > 0 && click < 1 && (
        <div
          style={abs(1374 - 30 * click, 306 - 30 * click, {
            width: 60 * click,
            height: 60 * click,
            borderRadius: "50%",
            border: "3px solid #6da8ff",
            opacity: 1 - click,
          })}
        />
      )}
      <Footer t={t} offset={27}>
        {t < 4
          ? "Each row pairs the water state with temperature, humidity and a reading ID."
          : "Choose a time period, then export the loaded rows as a CSV for your report."}
      </Footer>
    </Surface>
  );
}
function Climate() {
  const t = Time(),
    rules = t >= 5,
    beep = t >= 10.5;
  return (
    <Surface color={rules ? "#eaf0fc" : "#f4f6fa"}>
      <Brand tab="Humidity · Trends and rules" />
      <Rise t={t}>
        <Text x={72} y={134} size={76} weight={630}>
          {rules
            ? beep
              ? "Why did the buzzer beep?"
              : "How long was the room humid?"
            : "Was it a spike or a trend?"}
        </Text>
      </Rise>
      {!rules ? (
        <>
          <Shot
            name="chart"
            x={72}
            y={262}
            w={836}
            style={{ boxShadow: shadow, borderRadius: 17 }}
          />
          <Label x={974} y={324}>
            CLIMATE TREND
          </Label>
          <Text x={970} y={381} w={525} size={65} leading={1.03}>
            Follow the blue humidity line.
          </Text>
          <Text
            x={973}
            y={560}
            w={515}
            size={30}
            leading={1.26}
            spacing={-0.026}
            color="#50617c"
          >
            The dashed line marks the warning threshold.
          </Text>
        </>
      ) : (
        <>
          <div
            style={abs(72, 283, {
              width: 882,
              height: 355,
              background: "white",
              borderRadius: 18,
              boxShadow: shadow,
            })}
          >
            <Shot name="humidityRules" x={30} y={43} w={822} />
          </div>
          <Label x={1004} y={319}>
            {beep ? "ON THE ESP32" : "ON THE SERVER"}
          </Label>
          <Text
            x={997}
            y={374}
            w={505}
            size={beep ? 84 : 75}
            color={blue}
            weight={650}
            leading={1.02}
          >
            {beep ? "1 second" : "30 minutes"}
          </Text>
          <Text x={1003} y={488} w={462} size={33} leading={1.22} spacing={-0.03}>
            {beep
              ? "One beep after two consecutive samples at or above 75.5% RH."
              : "A warning needs sustained readings at or above 75.5% RH."}
          </Text>
        </>
      )}
      <Footer t={t} offset={35}>
        {beep
          ? "Two consecutive readings below 73% RH rearm the humidity beep."
          : rules
            ? "A critical humidity incident needs at least 80% RH for 15 minutes. Recovery takes 10 minutes below 73%."
            : "Open Climate trend to compare humidity or temperature across the selected period."}
      </Footer>
    </Surface>
  );
}
function Health() {
  const t = Time();
  return (
    <Surface color={navy}>
      <Dots dark />
      <Brand dark tab="Device · Reporting status" />
      <Rise t={t}>
        <Text x={70} y={212} w={688} size={88} weight={620} color="white" leading={1.02}>
          Server connected.
          <br />
          <span style={{ color: "#a7c8ff" }}>Device offline?</span>
        </Text>
      </Rise>
      <Text
        x={77}
        y={485}
        w={620}
        size={34}
        leading={1.28}
        spacing={-0.028}
        color="#d5e3ff"
      >
        Check the last accepted reading. The browser and the ESP32 have separate
        connections.
      </Text>
      <motion.div
        style={abs(786, 182, {
          width: 730,
          height: 465,
          overflow: "hidden",
          borderRadius: 22,
          background: "white",
          boxShadow: shadow,
          opacity: ease(t, 0.18, 1),
          y: (1 - ease(t, 0.18, 1)) * 32,
        })}
      >
        <Shot name="offline" w={730} />
      </motion.div>
      <Footer dark t={t} offset={50}>
        After five minutes without an accepted reading, Device health shows Offline.
      </Footer>
    </Surface>
  );
}
function End() {
  const t = Time(),
    p = ease(t, 0, 0.75);
  return (
    <Surface color="#2455cd">
      <Dots dark />
      <Brand dark tab="Records Room · DOC-ROOM-01" />
      <motion.div
        style={abs(76, 211, {
          width: 90,
          height: 90,
          borderRadius: 24,
          background: "white",
          color: blue,
          display: "grid",
          placeItems: "center",
          scale: 0.8 + 0.2 * p,
          opacity: p,
        })}
      >
        <Archive size={61} />
      </motion.div>
      <Rise t={t} delay={0.12}>
        <Text x={68} y={345} w={1470} size={112} weight={650} color="white">
          Document Storage Monitor
        </Text>
        <Text
          x={76}
          y={518}
          w={1320}
          size={45}
          leading={1.2}
          color="#e6efff"
          weight={430}
          spacing={-0.035}
        >
          Overview for now. Alert history for what happened.
        </Text>
      </Rise>
      <Footer dark t={t} offset={59}>
        ESP32 → MQTT broker → monitoring server → WebSocket → dashboard
      </Footer>
    </Surface>
  );
}
function Film() {
  return (
    <AbsoluteFill style={{ fontFamily: fonts }}>
      <style>
        {"@font-face{font-family:Geist;src:url(" +
          staticFile("geist.woff2") +
          ') format("woff2");font-style:normal;font-weight:100 900}*{box-sizing:border-box}'}
      </style>
      <div
        style={{
          position: "absolute",
          width: 1600,
          height: 900,
          transform: "scale(1.2)",
          transformOrigin: "0 0",
          overflow: "hidden",
        }}
      >
        <Sequence name="Room overview" durationInFrames={6 * FPS}>
          <Open />
        </Sequence>
        <Sequence name="Water at the probe" from={6 * FPS} durationInFrames={10 * FPS}>
          <Water />
        </Sequence>
        <Sequence
          name="Water incident history"
          from={16 * FPS}
          durationInFrames={11 * FPS}
        >
          <History />
        </Sequence>
        <Sequence
          name="Saved readings and CSV"
          from={27 * FPS}
          durationInFrames={8 * FPS}
        >
          <Readings />
        </Sequence>
        <Sequence
          name="Humidity trend and alarms"
          from={35 * FPS}
          durationInFrames={15 * FPS}
        >
          <Climate />
        </Sequence>
        <Sequence name="Device health" from={50 * FPS} durationInFrames={9 * FPS}>
          <Health />
        </Sequence>
        <Sequence name="End card" from={59 * FPS} durationInFrames={5 * FPS}>
          <End />
        </Sequence>
      </div>
      <Audio src={staticFile("score.wav")} />
    </AbsoluteFill>
  );
}
function Root() {
  return (
    <Composition
      id="DashboardTour"
      component={Film}
      durationInFrames={DURATION * FPS}
      fps={FPS}
      width={1920}
      height={1080}
    />
  );
}
registerRoot(Root);
