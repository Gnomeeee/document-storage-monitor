const fs = require("node:fs");
const path = require("node:path");
const rate = 44100,
  duration = 64,
  count = rate * duration;
const left = new Float32Array(count),
  right = new Float32Array(count);
const tau = 2 * Math.PI;
function hz(note) {
  return 440 * 2 ** ((note - 69) / 12);
}
function add(at, len, pan, make) {
  const start = Math.floor(at * rate),
    n = Math.min(Math.floor(len * rate), count - start);
  const l = Math.sqrt((1 - pan) / 2),
    r = Math.sqrt((1 + pan) / 2);
  for (let i = 0; i < n; i++) {
    const v = make(i / rate, i);
    left[start + i] += v * l;
    right[start + i] += v * r;
  }
}
function key(at, note, level, pan = 0, decay = 2.3) {
  const f = hz(note);
  add(at, decay * 2, pan, (t) => {
    const e = (1 - Math.exp(-t * 210)) * Math.exp((-t * 4) / decay);
    return (
      level *
      e *
      (Math.sin(tau * f * t + 1.6 * Math.exp(-t * 9) * Math.sin(tau * f * 2 * t)) +
        0.25 * Math.sin(tau * f * 2 * t))
    );
  });
}
function bass(at, note, hold) {
  const f = hz(note);
  add(
    at,
    hold,
    0,
    (t) =>
      0.13 *
      Math.min(1, t * 110) *
      Math.min(1, (hold - t) * 12) *
      (Math.sin(tau * f * t) + 0.24 * Math.sin(tau * 2 * f * t)) *
      (1 - (0.35 * t) / hold),
  );
}
let seed = 199;
const noise = () => {
  seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
  return seed / 2147483648 - 1;
};
function hat(at, open = false) {
  let prev = 0;
  add(at, open ? 0.17 : 0.075, 0.34, (t) => {
    const x = noise(),
      v = x - prev;
    prev = x;
    return 0.028 * v * Math.exp(-t * (open ? 31 : 76)) * Math.min(t * 500, 1);
  });
}
function kick(at, level = 1) {
  add(
    at,
    0.32,
    0,
    (t) =>
      level *
      0.3 *
      Math.sin(tau * (47 * t + 2.6 * (1 - Math.exp(-t * 31)))) *
      Math.exp(-t * 13) *
      Math.min(1, t * 400),
  );
}
function brush(at) {
  let smooth = 0;
  add(at, 0.14, -0.2, (t) => {
    smooth = 0.6 * smooth + 0.4 * noise();
    return (
      (0.08 * smooth + 0.035 * Math.sin(tau * 194 * t)) *
      Math.exp(-t * 32) *
      Math.min(t * 420, 1)
    );
  });
}
const chords = [
  [50, 57, 61, 66, 69],
  [45, 52, 59, 61, 64],
  [47, 54, 57, 62, 66],
  [43, 50, 57, 59, 62],
];
for (let bar = 0; bar < 31; bar++) {
  const at = bar * 2,
    c = chords[Math.floor(bar / 2) % 4];
  if (at < 60) {
    c.slice(1).forEach((note, j) =>
      key(at + 0.018 * j, note, 0.044, [-0.5, -0.2, 0.18, 0.5][j], 2.5),
    );
  }
  if (bar > 1 && at < 60) {
    bass(at, c[0] - 12, 0.68);
    bass(at + 1.25, c[0] - 12, 0.35);
    kick(at, 0.77);
    kick(at + 1, 0.55);
    brush(at + 0.5);
    brush(at + 1.5);
    for (let j = 0; j < 8; j++)
      if (j % 2 === 1 || bar % 4 === 3) hat(at + j * 0.25, j === 7 && bar % 2 === 1);
    if (bar % 2 === 0 || bar % 4 === 3) {
      const steps = [1, 4, 2, 3];
      steps.forEach((s, i) =>
        key(
          at + 0.25 + i * 0.375,
          c[s] + 12,
          i === 0 ? 0.049 : 0.032,
          i % 2 ? 0.42 : -0.35,
          1,
        ),
      );
    }
  }
}
function sweep(end, vol = 0.14) {
  let lp = 0;
  add(end - 0.48, 0.48, -0.1, (t) => {
    lp += 0.18 * (noise() - lp);
    return vol * lp * (t / 0.48) ** 2 * Math.min(1, (0.48 - t) * 52);
  });
}
function tick(time, down = false) {
  key(time, down ? 66 : 83, 0.22, -0.14, 0.36);
  key(time + 0.085, down ? 61 : 90, 0.12, 0.22, 0.49);
}
for (const time of [6, 16, 27, 35, 40, 50, 59]) sweep(time);
tick(0.36);
tick(6.45);
tick(16.4);
tick(27.4);
tick(32.2);
tick(40.45);
tick(50.4);
function water(time) {
  add(
    time,
    0.55,
    -0.08,
    (t) =>
      0.31 *
      Math.sin(tau * (360 * t + 18 * (1 - Math.exp(-t * 22)))) *
      Math.exp(-t * 11) *
      Math.min(1, t * 350),
  );
  key(time + 0.16, 78, 0.2, 0.22, 0.64);
}
water(10.5);
[73, 78, 81].forEach((n, i) => key(21.5 + i * 0.105, n, 0.23, [-0.24, 0, 0.28][i], 1.0));
add(
  46.65,
  1,
  0.05,
  (t) =>
    0.075 *
    (Math.sin(tau * 880 * t) + 0.17 * Math.sin(tau * 1760 * t)) *
    Math.min(1, t * 70, (1 - t) * 55),
);
[50, 57, 62, 66, 69, 74].forEach((n, i) =>
  key(60 + i * 0.14, n, 0.11, i * 0.12 - 0.34, 3.5),
);
let max = 0;
for (let i = 0; i < count; i++)
  max = Math.max(max, Math.abs(left[i]), Math.abs(right[i]));
const gain = 0.8 / max,
  b = Buffer.alloc(44 + count * 4);
b.write("RIFF");
b.writeUInt32LE(b.length - 8, 4);
b.write("WAVEfmt ", 8);
b.writeUInt32LE(16, 16);
b.writeUInt16LE(1, 20);
b.writeUInt16LE(2, 22);
b.writeUInt32LE(rate, 24);
b.writeUInt32LE(rate * 4, 28);
b.writeUInt16LE(4, 32);
b.writeUInt16LE(16, 34);
b.write("data", 36);
b.writeUInt32LE(count * 4, 40);
for (let i = 0; i < count; i++) {
  const a = gain * Math.min(1, (count - i) / (rate * 0.9));
  b.writeInt16LE(Math.round(left[i] * a * 32767), 44 + 4 * i);
  b.writeInt16LE(Math.round(right[i] * a * 32767), 46 + 4 * i);
}
fs.writeFileSync(path.join(__dirname, "public", "score.wav"), b);
console.log("64s stereo score written");
