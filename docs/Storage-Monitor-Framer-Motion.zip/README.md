# Storage Monitor dashboard tour

This 64-second composition uses Framer Motion and Remotion. The dashboard captures in `public` came from a local build of the React app running illustrative readings. You can preview and export the film offline once the packages and rendering browser are installed.

1. Extract the zip into a folder and open a terminal there.
2. Run `npm ci` to install the video dependencies.
3. Run `npm run preview` to see the dashboard tour in Remotion Studio.
4. Run `npm run render` to export the 1920 × 1080 MP4. Remotion can download its rendering browser on the first export.

Edit scene text and motion in `Film.jsx`. Edit the instrumental score and sound effects in `sound.cjs`. Preview and render both generate the soundtrack automatically.
